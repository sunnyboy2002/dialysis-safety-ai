
import React from 'react';
import { EvaluationResult } from '../types';

interface EvaluationResultViewProps {
  result: EvaluationResult;
}

const EvaluationResultView: React.FC<EvaluationResultViewProps> = ({ result }) => {
  const getRankColor = (rank: number) => {
    switch (rank) {
      case 5: return 'from-emerald-500 to-green-600';
      case 4: return 'from-blue-500 to-cyan-600';
      case 3: return 'from-amber-400 to-orange-500';
      case 2: return 'from-orange-500 to-red-500';
      case 1: return 'from-red-600 to-rose-700';
      default: return 'from-slate-400 to-slate-500';
    }
  };

  const getRankLabel = (rank: number) => {
    switch (rank) {
      case 5: return '非常に適切 (Excellent)';
      case 4: return '適切 (Good)';
      case 3: return '許容範囲 (Acceptable)';
      case 2: return '不十分 (Insufficient)';
      case 1: return '不適切・危険 (Critical)';
      default: return '判定不能';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden mb-10">
      <div className={`h-2 bg-gradient-to-r ${getRankColor(result.rank)}`} />
      
      <div className="p-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10 pb-8 border-b border-slate-100">
          <div>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-widest block mb-1">Evaluation Score</span>
            <div className="flex items-baseline space-x-2">
              <h3 className="text-4xl font-black text-slate-800">ランク {result.rank}</h3>
              <span className={`text-lg font-semibold bg-clip-text text-transparent bg-gradient-to-r ${getRankColor(result.rank)}`}>
                {getRankLabel(result.rank)}
              </span>
            </div>
          </div>
          
          <div className="flex space-x-1">
            {[1, 2, 3, 4, 5].map((s) => (
              <div 
                key={s} 
                className={`w-10 h-3 rounded-full ${s <= result.rank ? `bg-gradient-to-r ${getRankColor(result.rank)}` : 'bg-slate-100'}`}
              />
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-10">
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-green-700 flex items-center px-3 py-1 bg-green-50 rounded-lg w-fit">
              <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
              </svg>
              良かった点
            </h4>
            <p className="text-slate-700 leading-relaxed text-sm bg-slate-50 p-4 rounded-xl border border-slate-100">
              {result.reasonGood}
            </p>
          </div>
          
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-red-700 flex items-center px-3 py-1 bg-red-50 rounded-lg w-fit">
              <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
              懸念点
            </h4>
            <p className="text-slate-700 leading-relaxed text-sm bg-slate-50 p-4 rounded-xl border border-slate-100">
              {result.reasonBad}
            </p>
          </div>
        </div>

        <div className="bg-blue-50 rounded-2xl p-6 border border-blue-100">
          <h4 className="text-sm font-bold text-blue-800 flex items-center mb-4">
            <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            医療安全管理者からのアドバイス
          </h4>
          <div className="text-slate-700 text-sm leading-relaxed whitespace-pre-wrap pl-7 border-l-2 border-blue-200">
            {result.advice}
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-slate-100 text-center">
          <p className="text-[10px] text-slate-400">
            ※本評価はAIによる分析結果です。最終的な判断は各施設の医療安全マニュアルに従ってください。
          </p>
        </div>
      </div>
    </div>
  );
};

export default EvaluationResultView;
