
import React from 'react';
import { IncidentReport } from '../types';

interface EvaluationFormProps {
  report: IncidentReport;
  setReport: (report: IncidentReport) => void;
  onEvaluate: () => void;
  onClear: () => void;
  loading: boolean;
}

const EvaluationForm: React.FC<EvaluationFormProps> = ({ report, setReport, onEvaluate, onClear, loading }) => {
  return (
    <div className="space-y-5">
      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-1.5">
          事例内容 <span className="text-red-500 font-normal">*</span>
        </label>
        <textarea
          className="w-full h-24 px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all outline-none resize-none text-slate-800"
          placeholder="例：透析中に回路が外れて出血した。"
          value={report.incident}
          onChange={(e) => setReport({ ...report, incident: e.target.value })}
        />
      </div>

      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-1.5">
          処理（実施した処置） <span className="text-red-500 font-normal">*</span>
        </label>
        <textarea
          className="w-full h-24 px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all outline-none resize-none text-slate-800"
          placeholder="例：すぐに回路を接続し直した。圧迫止血を行い、止血を確認した。"
          value={report.treatment}
          onChange={(e) => setReport({ ...report, treatment: e.target.value })}
        />
      </div>

      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-1.5">
          発生後の対応経過（報告・説明など）
        </label>
        <textarea
          className="w-full h-24 px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all outline-none resize-none text-slate-800"
          placeholder="例：患者には寝ていたので伝えなかった。医師には終了後に報告した。"
          value={report.progress}
          onChange={(e) => setReport({ ...report, progress: e.target.value })}
        />
      </div>

      <div className="flex flex-col sm:flex-row gap-3 pt-2">
        <button
          onClick={onEvaluate}
          disabled={loading || !report.incident || !report.treatment}
          className={`flex-1 flex items-center justify-center px-6 py-3 rounded-lg font-bold text-white transition-all shadow-sm ${
            loading || !report.incident || !report.treatment
              ? 'bg-blue-300 cursor-not-allowed'
              : 'bg-blue-600 hover:bg-blue-700 active:scale-95'
          }`}
        >
          {loading ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              評価中...
            </>
          ) : (
            '対応を評価する'
          )}
        </button>
        <button
          onClick={onClear}
          className="px-6 py-3 rounded-lg font-semibold text-slate-500 bg-slate-100 hover:bg-slate-200 transition-colors"
        >
          リセット
        </button>
      </div>
    </div>
  );
};

export default EvaluationForm;
