
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-blue-600 text-white shadow-md">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex items-center space-x-3">
          <div className="bg-white p-2 rounded-lg">
            <svg className="w-8 h-8 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M12.395 2.553a1 1 0 00-1.45-.385c-.345.23-.614.558-.822.88-.214.33-.403.713-.57 1.116-.334.804-.614 1.768-.84 2.734a31.365 31.365 0 00-.613 3.58 2.64 2.64 0 011.512-.306c.386.03.762.16 1.11.381.348.221.653.53.888.916.236.385.38.85.417 1.36.037.51-.034 1.022-.213 1.479a3.198 3.198 0 01-1.09 1.397 3.1 3.1 0 01-1.394.587c-.448.092-.9.085-1.351-.017a3.15 3.15 0 01-1.207-.544 3.131 3.131 0 01-.865-1.172 3.197 3.197 0 01-.29-1.323c-.033-.521.055-1.039.261-1.503l-.008.001a31.31 31.31 0 01.59-3.516c.215-.944.481-1.856.773-2.64.29-.78.588-1.44.896-1.92.31-.476.657-.804 1.02-.948a1 1 0 00.122-1.885z" clipRule="evenodd" />
            </svg>
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">透析医療 安全管理AI評価システム</h1>
            <p className="text-blue-100 text-sm opacity-90">Medical Safety Manager AI Evaluator</p>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
